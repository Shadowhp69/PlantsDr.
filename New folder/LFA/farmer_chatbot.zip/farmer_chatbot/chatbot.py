# chatbot.py
import os
import google.generativeai as genai
from dotenv import load_dotenv
from knowledge_retriever import find_relevant_knowledge

load_dotenv()
genai.configure(api_key=os.getenv("GOOGLE_API_KEY"))
model = genai.GenerativeModel('gemini-1.5-flash-latest')

def get_bot_response(user_query, language='en'):
    # Step 1: Get knowledge base context
    context = find_relevant_knowledge(user_query)

    # Step 2: Build prompt
    prompt = f"""
    You are an expert agricultural assistant for farmers in Modasa, Gujarat, India.
    Today's date is September 13, 2025.
    The farmer's preferred language is {language}. Answer in that language.

    Use the following context if relevant:
    ---CONTEXT---
    {context}
    ---END CONTEXT---

    Farmer's query: "{user_query}"
    Your response:
    """

    try:
        response = model.generate_content(prompt)
        return response.text
    except Exception as e:
        print(f"Error getting response from AI: {e}")
        return "⚠️ Sorry, I am having trouble connecting to AI right now."
