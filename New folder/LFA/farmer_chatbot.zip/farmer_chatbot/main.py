# main.py
import sqlite3
from chatbot import get_bot_response

# --- Database ---
def get_db_connection():
    conn = sqlite3.connect('farmers_data.db')
    conn.row_factory = sqlite3.Row
    return conn

def get_or_create_farmer(phone_number):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM farmers WHERE phone_number = ?", (phone_number,))
    farmer = cursor.fetchone()
    if farmer is None:
        cursor.execute("INSERT INTO farmers (phone_number, language_preference) VALUES (?, ?)", (phone_number, "en"))
        conn.commit()
        cursor.execute("SELECT * FROM farmers WHERE phone_number = ?", (phone_number,))
        farmer = cursor.fetchone()
    conn.close()
    return farmer

def log_chat(farmer_id, user_message, bot_response):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO chat_logs (farmer_id, user_message, bot_response) VALUES (?, ?, ?)",
        (farmer_id, user_message, bot_response)
    )
    conn.commit()
    conn.close()

# --- Fake prediction API ---
def get_farmer_crop_info(farmer_id):
    return {"crop_name": "cotton", "sowing_date": "2025-06-25"}

def get_harvest_prediction(crop_name, sowing_date):
    if crop_name == "cotton" and sowing_date == "2025-06-25":
        return "2026-01-20"
    return None

# --- Main Handler ---
def handle_incoming_message(phone_number, user_message):
    farmer = get_or_create_farmer(phone_number)
    farmer_id = farmer['farmer_id']
    language = farmer['language_preference']

    bot_response = ""
    msg = user_message.lower()

    # Intent: harvest prediction
    if "harvest" in msg or "કાપણી" in msg:
        crop_info = get_farmer_crop_info(farmer_id)
        predicted_date = get_harvest_prediction(crop_info['crop_name'], crop_info['sowing_date'])
        if predicted_date:
            bot_response = f"🌱 Based on your sowing date {crop_info['sowing_date']}, your {crop_info['crop_name']} is expected to be ready for harvest around {predicted_date}."
        else:
            bot_response = "Sorry, I couldn’t fetch your harvest prediction right now."

    # Fallback: general RAG chatbot
    if not bot_response:
        bot_response = get_bot_response(user_message, language)

    log_chat(farmer_id, user_message, bot_response)
    return bot_response

# --- Simulation ---
if __name__ == "__main__":
    phone = "+919876543210"

    msg1 = "Rice production in Durg 1970"
    print(f"\n👨‍🌾 Farmer: {msg1}")
    print("🤖 Bot:", handle_incoming_message(phone, msg1))

    msg2 = "When should I do the kapani for my cotton?"
    print(f"\n👨‍🌾 Farmer: {msg2}")
    print("🤖 Bot:", handle_incoming_message(phone, msg2))
