# database.py
import sqlite3
import logging

DB_NAME = 'farmers_data.db'

def get_db_connection():
    try:
        conn = sqlite3.connect(DB_NAME, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        return conn
    except Exception as e:
        logging.error(f"DB connection error: {e}")
        raise

def create_database():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS farmers (
            farmer_id INTEGER PRIMARY KEY AUTOINCREMENT,
            phone_number TEXT UNIQUE NOT NULL,
            name TEXT,
            language_preference TEXT DEFAULT 'en',
            location TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        ''')
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS chat_logs (
            log_id INTEGER PRIMARY KEY AUTOINCREMENT,
            farmer_id INTEGER,
            user_message TEXT,
            bot_response TEXT,
            timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (farmer_id) REFERENCES farmers (farmer_id)
        )
        ''')
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS crop_data (
            crop_id INTEGER PRIMARY KEY AUTOINCREMENT,
            farmer_id INTEGER,
            crop_name TEXT NOT NULL,
            sowing_date DATE,
            status TEXT,
            FOREIGN KEY (farmer_id) REFERENCES farmers (farmer_id)
        )
        ''')
        conn.commit()
        logging.info("Database and tables created successfully.")
    except Exception as e:
        logging.error(f"Error creating database: {e}")
    finally:
        conn.close()


# chatbot.py
import os
import logging
import google.generativeai as genai
from dotenv import load_dotenv
from knowledge_retriever import find_relevant_knowledge

load_dotenv()

genai.configure(api_key=os.getenv("GOOGLE_API_KEY"))
model = genai.GenerativeModel('gemini-1.5-flash-latest')

def get_bot_response(user_query, language='en'):
    context = find_relevant_knowledge(user_query)
    prompt = f"""
    You are an expert agricultural assistant for farmers in Modasa, Gujarat, India.
    Today's date is September 13, 2025.
    The farmer's preferred language is {language}. Answer in that language.
    Use the following context if relevant:
    ---CONTEXT---
    {context}
    ---END CONTEXT---
    Farmer's query: "{user_query}"
    Your response:
    """
    try:
        response = model.generate_content(prompt)
        return response.text
    except Exception as e:
        logging.error(f"AI response error: {e}")
        return "⚠ Sorry, I am having trouble connecting to AI right now."


# main.py
import logging
import re
from database import get_db_connection
from chatbot import get_bot_response

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s: %(message)s')

def sanitize_phone_number(raw_phone):
    # Remove whatsapp: prefix and validate phone number format (basic)
    if raw_phone.startswith("whatsapp:"):
        raw_phone = raw_phone.replace("whatsapp:", "")
    # Basic validation: keep only + and digits
    sanitized = re.sub(r'[^\d+]', '', raw_phone)
    return sanitized

def get_or_create_farmer(raw_phone):
    phone_number = sanitize_phone_number(raw_phone)
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM farmers WHERE phone_number = ?", (phone_number,))
    farmer = cursor.fetchone()
    if farmer is None:
        cursor.execute("INSERT INTO farmers (phone_number, language_preference) VALUES (?, ?)", (phone_number, "en"))
        conn.commit()
        cursor.execute("SELECT * FROM farmers WHERE phone_number = ?", (phone_number,))
        farmer = cursor.fetchone()
        logging.info(f"Created new farmer record for {phone_number}")
    conn.close()
    return farmer

def log_chat(farmer_id, user_message, bot_response):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO chat_logs (farmer_id, user_message, bot_response) VALUES (?, ?, ?)",
            (farmer_id, user_message, bot_response)
        )
        conn.commit()
    except Exception as e:
        logging.error(f"Error logging chat: {e}")
    finally:
        conn.close()

def get_farmer_crop_info(farmer_id):
    # For demo, returning static info
    return {"crop_name": "cotton", "sowing_date": "2025-06-25"}

def get_harvest_prediction(crop_name, sowing_date):
    if crop_name == "cotton" and sowing_date == "2025-06-25":
        return "2026-01-20"
    return None

def handle_incoming_message(raw_phone, user_message):
    farmer = get_or_create_farmer(raw_phone)
    farmer_id = farmer['farmer_id']
    language = farmer['language_preference']

    bot_response = ""
    msg = user_message.lower()

    if "harvest" in msg or "કાપણી" in msg:  # keywords for harvest
        crop_info = get_farmer_crop_info(farmer_id)
        predicted_date = get_harvest_prediction(crop_info['crop_name'], crop_info['sowing_date'])
        if predicted_date:
            bot_response = f"🌱 Based on your sowing date {crop_info['sowing_date']}, your {crop_info['crop_name']} is expected to be ready for harvest around {predicted_date}."
        else:
            bot_response = "Sorry, I couldn’t fetch your harvest prediction right now."

    if not bot_response:
        bot_response = get_bot_response(user_message, language)

    log_chat(farmer_id, user_message, bot_response)
    return bot_response


# app.py (Flask server)
from flask import Flask, request
from twilio.twiml.messaging_response import MessagingResponse
from main import handle_incoming_message

app = Flask(_name_)

@app.route("/sms", methods=['POST'])
def sms_reply():
    user_message = request.form.get('Body')
    sender = request.form.get('From')

    if not user_message or not sender:
        return "Invalid request", 400

    logging.info(f"Received message from {sender}: {user_message}")

    # Normalize phone number for DB & handling
    phone_number = sender
    if sender.startswith("whatsapp:"):
        phone_number = sender.replace("whatsapp:", "")

    bot_response = handle_incoming_message(phone_number, user_message)

    resp = MessagingResponse()
    msg = resp.message(bot_response)

    # If WhatsApp, reply on WhatsApp channel
    if sender.startswith("whatsapp:"):
        msg.attr("to", sender)

    return str(resp)


if _name_ == '_main_':
    from database import create_database
    create_database()  # Ensure DB and tables exist before app start
    app.run(debug=True, port=5000)