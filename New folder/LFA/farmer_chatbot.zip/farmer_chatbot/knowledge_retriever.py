# knowledge_retriever.py
import pandas as pd

# Load dataset
df = pd.read_csv("knowledge_base.csv")

def find_relevant_knowledge(query: str):
    """
    Searches the knowledge base (CSV) for relevant crop info
    based on state, district, year, or crop keywords.
    """
    query = query.lower()
    results = pd.DataFrame()

    # --- Match year ---
    for year in df['Year'].unique():
        if str(year) in query:
            results = df[df['Year'] == year]

    # --- Match state ---
    for state in df['State Name'].unique():
        if state.lower() in query:
            results = df[df['State Name'].str.lower() == state.lower()]

    # --- Match district ---
    for dist in df['Dist Name'].unique():
        if dist.lower() in query:
            results = df[df['Dist Name'].str.lower() == dist.lower()]

    # --- Crop keywords ---
    crop_map = {
        "rice": ["RICE AREA (1000 ha)", "RICE PRODUCTION (1000 tons)", "RICE YIELD (Kg per ha)"],
        "wheat": ["WHEAT AREA (1000 ha)", "WHEAT PRODUCTION (1000 tons)", "WHEAT YIELD (Kg per ha)"],
        "maize": ["MAIZE AREA (1000 ha)", "MAIZE PRODUCTION (1000 tons)", "MAIZE YIELD (Kg per ha)"],
        "sugarcane": ["SUGARCANE AREA (1000 ha)", "SUGARCANE PRODUCTION (1000 tons)", "SUGARCANE YIELD (Kg per ha)"],
        "cotton": ["COTTON AREA (1000 ha)", "COTTON PRODUCTION (1000 tons)", "COTTON YIELD (Kg per ha)"]
    }

    for crop, cols in crop_map.items():
        if crop in query:
            if not results.empty:
                return results[["Year", "State Name", "Dist Name"] + cols].head(5).to_string(index=False)
            else:
                return df[["Year", "State Name", "Dist Name"] + cols].head(5).to_string(index=False)

    return "No relevant data found in knowledge base."
