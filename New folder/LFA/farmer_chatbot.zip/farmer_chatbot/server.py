from flask import Flask, request
from twilio.twiml.messaging_response import MessagingResponse
from main import handle_incoming_message # Import your main logic

app = Flask(__name__)

@app.route("/sms", methods=['POST'])
def sms_reply():
    # Get the message the user sent
    user_message = request.form.get('Body')
    # Get the sender's phone number
    phone_number = request.form.get('From')

    print(f"Received SMS from {phone_number}: {user_message}")

    # Use your existing logic to get a response
    bot_response = handle_incoming_message(phone_number, user_message)

    # Create a TwiML response to send back a message
    resp = MessagingResponse()
    resp.message(bot_response)

    return str(resp)

if __name__ == "__main__":
    # To make this publicly accessible, you'll need a tool like ngrok during development
    # In production, you would deploy this on a real server.
    app.run(debug=True, port=5000)