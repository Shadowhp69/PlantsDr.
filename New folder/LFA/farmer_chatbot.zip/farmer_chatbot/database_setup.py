import sqlite3

def create_database():
    # Connect to the database (it will be created if it doesn't exist)
    conn = sqlite3.connect('farmers_data.db')
    cursor = conn.cursor()

    # Create 'farmers' table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS farmers (
        farmer_id INTEGER PRIMARY KEY AUTOINCREMENT,
        phone_number TEXT UNIQUE NOT NULL,
        name TEXT,
        language_preference TEXT DEFAULT 'en', -- e.g., 'en', 'hi', 'gu'
        location TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    ''')

    # Create 'chat_logs' table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS chat_logs (
        log_id INTEGER PRIMARY KEY AUTOINCREMENT,
        farmer_id INTEGER,
        user_message TEXT,
        bot_response TEXT,
        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (farmer_id) REFERENCES farmers (farmer_id)
    )
    ''')

    # Create 'crop_data' table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS crop_data (
        crop_id INTEGER PRIMARY KEY AUTOINCREMENT,
        farmer_id INTEGER,
        crop_name TEXT NOT NULL,
        sowing_date DATE,
        status TEXT, -- e.g., 'sown', 'growing', 'harvested'
        FOREIGN KEY (farmer_id) REFERENCES farmers (farmer_id)
    )
    ''')

    print("Database and tables created successfully.")
    conn.commit()
    conn.close()

if __name__ == '__main__':
    create_database()